##这是对降水P--TanHui的值的一个比较

##首先，下载-加载需要的操作包
setwd("E:\\space_R\\2")
install.packages("plotRCS")
install.packages("ggplot2")
install.packages("rms")
install.packages("lubridate")
install.packages("xts")
library(plotRCS)
library(ggplot2)
library(rms) 
library(lubridate)
library(xts)
library(tidyverse)

dd <- read.csv(file.choose())#############################做HR的时候改成mydata----做RCS画图的时候
head(dd)

x = dd$Pmean
y = dd$TanHuimean
model <- lm(y ~ x)

# restricted cubic spline
model.spline1 <- lm(y ~ rcs(x, 3))
model.spline2 <- lm(y ~ rcs(x, 5))
model.spline3 <- lm(y ~ rcs(x, 7))
model.spline4 <- lm(y ~ rcs(x, 9))
model.spline5 <- lm(y ~ rcs(x, 10))

# compare models (to determine number of knots)
AIC(model.spline1,model.spline2,model.spline3,model.spline4,model.spline5)











#K斜率的高低，代表的就是P降水对于T的促进和抑制----暂时的定了另外一个1450--5,8节点
ggplot(data=dd, aes(x=x, y=y))+
  #ggtitle("Threshold recognition map")+
  guides(color = "none",shape = 'none')+
  geom_point(aes(color = dd$PYYNN),size = 0.3)+
  scale_color_manual(values = c('Threshold line'='red','Scatter point'='blue'))+
  geom_smooth(aes(x=PP,y=TH),method = 'lm', formula = y ~ rcs(x, 9),se = FALSE,size = 1.2,color = "firebrick")+
  #scale_fill_manual (values=c ('Threshold line'='red','Scatter point'='blue',0.5))+
  #labs(x = "precipitation（mm）", y = "Total carbon sink(g CO2 m-2 a-1)",color = "legend") +
  theme_classic()+
  #坐标轴的美化
  labs(x = "Precipitation（mm）", y = "Total carbon sink(g CO2 m-2 a-1)")+
  theme(axis.title = element_text(size = 10, color = "black"))+
  
  ##对坐标轴文本的优化
  theme(axis.text = element_text(color = "black", size = 8),
        axis.text.x = element_text(face = "italic"))+
  #旋转坐标轴文本
  theme(axis.text.x = element_text(angle = 0, vjust = 1, hjust = 1, size = 8))+
  
  #设置点的颜色
  
  scale_x_continuous(limits = c(1215,2050),breaks = seq(1200,2100,100))+
  #scale_y_continuous(breaks = seq(-1200,2800,400))+
  #scale_y_continuous(limits = c(-1200,2800))
  #设置垂直于Y轴的线
  #geom_hline(yintercept=0, linetype=2,size=1)+
  #geom_vline(xintercept=1680,size=1,color = 'black')+
  geom_vline(xintercept=1430,size=1,color = 'black')+
  #geom_vline(xintercept=1625,size=1,color = 'black')+
  annotate("text",x=1470,y=2900,label="1430",size=4,col="black")+
  annotate("text",x=1940,y=2900,label="R2=0.7436",size=4,col="red")
  #以上是图像的美化
 
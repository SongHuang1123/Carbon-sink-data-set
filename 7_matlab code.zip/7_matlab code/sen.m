[a,R]=geotiffread('E:\ruselt-all\RCF\2003.tif');%先导入投影信�?
info=geotiffinfo('E:\ruselt-all\RCF\2003.tif');
[m,n]=size(a);
cd=2022-2000+1;%时间跨度，根据需要自行修�?
datasum=zeros(m*n,cd)+NaN; 
k=1;
for year=2000:2022 %起始年份
    filename=['E:\ruselt-all\RCF\',int2str(year),'.tif'];
    data=importdata(filename);
    data=reshape(data,m*n,1);
    datasum(:,k)=data;
    k=k+1;
end
result=zeros(m,n)+NaN;
for i=1:size(datasum,1)
    data=datasum(i,:);
    if min(data)>-3000 %判断是否是有效�??,我这里的有效值必须大�?0
        valuesum=[];
        for k1=2:cd
            for k2=1:(k1-1)
                cz=data(k1)-data(k2);
                jl=k1-k2;
                value=cz./jl;
                valuesum=[valuesum;value];
            end
        end
        value=median(valuesum);
        result(i)=value;
    end
end
filename=['E:\ruselt-all\RCF\matlab\sen.tif'];
geotiffwrite(filename,result,R,'GeoKeyDirectoryTag',info.GeoTIFFTags.GeoKeyDirectoryTag)